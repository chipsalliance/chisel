=== Instructions for Running Hello World ===

Please make sure you have gcc installed, and that it is accessible through the command "gcc". 

Then type the following to compile helloworld.stanza
./stanza -platform os-x -i examples/helloworld.stanza -o helloworld

Run the program by typing:
./helloworld
