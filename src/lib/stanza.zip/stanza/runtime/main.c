extern void run_stanza(int argc, char** argv);
int main(int argc, char** argv){
  run_stanza(argc, argv);
  return 0;
}
