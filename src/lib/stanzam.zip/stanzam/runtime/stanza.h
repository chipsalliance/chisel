#ifndef STANZA_H
#define STANZA_H

//================= STANZA MACHINE ===========================
long run_stanza (int argc, char** argv);
long call_stanza (long f, int nargs, long* args);

//=================== GC ROOTS ===============================
int make_gcroot(long v);
long gcroot(int i);
long delete_gcroot(int i);

//================= PRIMITIVES ===============================
int prim_tag(long v);
#define INT_TAG 0
#define INT_TAG2 4
#define OBJECT_TAG 1
#define TRUE_TAG 2
#define FALSE_TAG 3
#define CHAR_TAG 5

int is_stz_int(long v);
long to_int(long stz_int);
long to_stz_int(long i);

int to_bool(long v);
long to_stz_bool(int b);

char to_char(long c);
long to_stz_char(char c);

//==================== OBJECTS ===============================
#define FN_TAG 0
#define STRING_TAG 5
#define RAWARRAY_TAG 6
#define COROUTINE_TAG 7
#define BOX_TAG 8
#define TUPLE_TAG 9
#define FLOAT_TAG 10
#define MEMBLOCK_TAG 11

void* untag(long v);
long to_ptr(void* v);

typedef struct {
  long tag;
  long slots[];
} Object;
int num_slots(Object* o);

//===================== BOXES ================================
long make_box(long x);
long box_get(long x);
long box_set(long x, long v);

//==================== CLOSURES ==============================
typedef struct {
  long tag;
  long code;
  long free[];
} Closure;
int num_free(Closure* c);

//================ STRINGS ===================================
typedef struct {
  long tag;
  long length;
  char chars[];
} String;
int num_words(String* s);

//================= ARRAYS ===================================
typedef struct {
  long tag;
  long length;
  long slots[];
} Array;
int num_array_slots(Array* a);
long array_make(long n, long x);
long array_get(long xs, long n);
long array_set(long xs, long n, long v);
long array_length(long xs);

//================= TUPLES ===================================
typedef struct {
  long tag;
  long length;  //(in stanza format)
  long slots[];
} Tuple;
int num_tuple_slots(Tuple* t);
long tuple_length(long xs);
long tuple_get(long xs, long n);

//================== FLOATS ==================================
typedef struct {
  long tag;
  double value;
} Float;
Float* make_float(double value);

//================== MEMBLOCKS ===============================
typedef struct {
  long tag;
  long bytes;
  long slots[];
} MemBlock;
MemBlock* make_memblock(int bytes);
int block_size(MemBlock* block);
void* block_ptr(MemBlock* block);

//============= COROUTINES AND STACKS ========================
#define COROUTINE_OPEN 0
#define COROUTINE_CLOSED 1
#define COROUTINE_SUSPENDED 2
#define COROUTINE_ENTRANCE 3

typedef struct StackSpace {
  struct StackSpace* next;
  long stack[];
} StackSpace;
StackSpace* make_stackspace(void);

typedef struct {
  long tag;
  long parent;
  long winders;
  long status;
  StackSpace* space;
  long* sp;
  long stanza_rbx;
  long stanza_rbp;
  long stanza_r12;
  long stanza_r13;
  long stanza_r14;
} Coroutine;
Coroutine* make_coroutine(long parent);

#endif
