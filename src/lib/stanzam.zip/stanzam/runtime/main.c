#include <stdio.h>
#include "stanza.h"

int main (int argc, char** argv){  
  run_stanza(argc, argv);
  return 0;
}
