#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <sys/param.h>
#include <errno.h>
#include "stanza.h"

//============================================================
//================= DECLARATIONS =============================
//============================================================

//============= EXTERNAL CONNECTIONS =========================
typedef struct {
  long size;
} ClassEntry;

typedef struct {
  long ret;
  char* description;
} StackMapEntry;

typedef struct {
  long num_entries;
  StackMapEntry entries[];
} StackMap;

extern long stanza_num_globals __asm__("stanza_num_globals");
extern long stanza_globals[] __asm__("stanza_globals");
extern long stanza_heap __asm__("stanza_heap");
extern long stanza_heap_top __asm__("stanza_heap_top");
extern long stanza_coroutine __asm__("stanza_coroutine");
extern long stanza_stack_top __asm__("stanza_stack_top");
extern long stanza_closure __asm__("stanza_closure");
extern long stanza_entry(void) __asm__("stanza_entry");
extern long stanza_start(long a0, long a1, long a2, long a3, long a4, long a5) __asm__("stanza_start");
extern long stack_finisher(void) __asm__("stack_finisher");
extern char* stanza_string_table[] __asm__("stanza_string_table");
extern double stanza_float_table[] __asm__("stanza_float_table");
extern ClassEntry stanza_class_table[] __asm__("stanza_class_table");
extern StackMap stanza_stack_mapping __asm__("stanza_stack_mapping");
extern long stanza_rax __asm__("stanza_rax");
extern long stanza_rcx __asm__("stanza_rcx");
extern long stanza_rdx __asm__("stanza_rdx");
extern long stanza_rsi __asm__("stanza_rsi");
extern long stanza_rdi __asm__("stanza_rdi");
extern long stanza_r8 __asm__("stanza_r8");
extern long stanza_r9 __asm__("stanza_r9");
extern long stanza_r10 __asm__("stanza_r10");
extern long stanza_r11 __asm__("stanza_r11");
extern long stanza_arity __asm__("stanza_arity");
extern long c_rbx __asm__("c_rbx");
extern long c_rsp __asm__("c_rsp");
extern long c_rbp __asm__("c_rbp");
extern long c_r12 __asm__("c_r12");
extern long c_r13 __asm__("c_r13");
extern long c_r14 __asm__("c_r14");
extern long c_r15 __asm__("c_r15");

//=============== MEMORY =====================================
void* heap_allocate(int size);
void set_current_heap(long* heap);

//=============== COROUTINE ==================================
void set_current_coroutine(Coroutine* c);

//=============== GARBAGE COLLECTION =========================
//Copy copies the given object to heap and returns the new
//heap pointer.
long copy_ptr(long ptr);
void copy_range(long* dest, long* src, int n);
long copy_closure(Closure* c);
long copy_object(Object* o);
long copy_string(String* s);
long copy_array(Array* ar);
long copy_tuple(Tuple* tup);
long copy_float(Float* f);
long copy_coroutine(Coroutine* c);
long copy_memblock(MemBlock* b);

//Link scans through the object and ensures all pointers
//point to the heap, and returns the next pointer to link.
long* link_range(long* p, int n);
long* link_coroutine(Coroutine* c);
long* link_closure(Closure* c);
long* link_object(Object* o);
long* link_string(String* s);
long* link_array(Array* ar);
long* link_tuple(Tuple* tup);
long* link_float(Float* f);
long* link_memblock(MemBlock* b);

//Links everything in heap starting from scan
void link_heap(void);
void extend_heap(long size);

//================ CONSISTENCY ===============================
void check_ptr(long ptr);
void check_coroutine(Coroutine* c);
void check_object(Object* o);
void check_closure(Closure* c);
void check_tuple(Tuple* tup);
void check_array(Array* a);
void check_range(long* p, int n);
void check_immediate(long x);

//============================================================
//============================================================
//============================================================

//================== DEBUG ===================================
long object_tag(long ptr){
  if(prim_tag(ptr) == OBJECT_TAG){
    Object* o = untag(ptr);
    return to_stz_int(o->tag);
  }else{
    return to_stz_int(prim_tag(ptr));
  }
}

//================== MIN/MAX =================================
static inline int min(int a, int b) {
  return a < b ? a : b;
}

static inline int max(int a, int b) {
  return a > b ? a : b;
}

//======================= VECTOR =============================
typedef struct {
  int length;
  int capacity;
  long* slots;
} Vector;

Vector* make_vector(int capacity){
  Vector* v = malloc(sizeof(Vector));
  v->length = 0;
  v->capacity = capacity;
  v->slots = malloc(capacity * sizeof(long));
  return v;
}

void ensure_vector_capacity(Vector* v, int c){
  if(c > v->capacity){
    int new_c = max(c, v->capacity * 2);
    long* slots = malloc(new_c * sizeof(long));
    memcpy(slots, v->slots, v->length * sizeof(long));
    free(v->slots);
    v->slots = slots;
  }
}

void vector_set(Vector* v, int i, long x){
  if(i < 0 || i >= v->length){
    fprintf(stderr, "Index %d is out of bounds.", i);
    exit(-1);
  }
  v->slots[i] = x;
}

long vector_get(Vector* v, int i){
  if(i < 0 || i >= v->length){
    fprintf(stderr, "Index %d is out of bounds.", i);
    exit(-1);
  }
  return v->slots[i];
}

void vector_add(Vector* v, long x){
  ensure_vector_capacity(v, v->length + 1);
  v->slots[v->length] = x;
  v->length++;  
}

long vector_pop(Vector* v){
  long x = vector_get(v, v->length - 1);
  v->length--;
  return x;
}

//====================== GC ROOTS ============================
struct {
  int cap;
  long* roots;  
  Vector* freelist;
} gcroots;

void init_gcroots(void){
  gcroots.cap = 10;
  gcroots.roots = malloc(gcroots.cap * sizeof(long));
  gcroots.freelist = make_vector(gcroots.cap);
  for(int i=0; i<gcroots.cap; i++){
    gcroots.roots[i] = FALSE_TAG;
    vector_add(gcroots.freelist, i);
  }
}

void ensure_freeroots(void){
  if(gcroots.freelist->length == 0){
    int new_c = gcroots.cap * 2;
    long* roots = malloc(new_c * sizeof(long));
    for(int i=0; i<gcroots.cap; i++)
      roots[i] = gcroots.roots[i];
    for(int i=gcroots.cap; i<new_c; i++){
      roots[i] = FALSE_TAG;
      vector_add(gcroots.freelist, i);
    }
    free(gcroots.roots);
    gcroots.roots = roots;    
  }
}

int make_gcroot(long x){
  ensure_freeroots();
  int i = vector_pop(gcroots.freelist);
  gcroots.roots[i] = x;
  return i;
}

long gcroot(int i){
  return gcroots.roots[i];
}

long delete_gcroot(int i){
  long x = gcroots.roots[i];
  gcroots.roots[i] = FALSE_TAG;
  vector_add(gcroots.freelist, i);
  return x;
}

//================== PRIMITIVES ==============================
int prim_tag(long v){
  return (int)v & 0x7;
}

int is_stz_int(long v){
  return ((int)v & 0x3) == 0;
}

long to_int(long stz_int){
  return stz_int >> 2;
}

long to_stz_int(long i){
  return i << 2;
}

int to_bool(long v){
  return v != FALSE_TAG;
}

long to_stz_bool(int b){
  return b? TRUE_TAG : FALSE_TAG;
}

char to_char(long c){
  return (char)(c >> 3);
}

long to_stz_char(char c){
  return ((long)c << 3) + CHAR_TAG;
}

//=================== OBJECTS ================================
int num_slots(Object* o){
  ClassEntry entry = stanza_class_table[o->tag];
  return entry.size;
}

long to_ptr(void* x){
  return (long)x + OBJECT_TAG;
}

void* untag(long x){
  return (void*)(x - OBJECT_TAG);
}

//================ BOXES =====================================
long make_box(long x){
  int gc_x = make_gcroot(x);
  Object* o = heap_allocate(16);
  o->tag = BOX_TAG;
  o->slots[0] = delete_gcroot(gc_x);
  return to_ptr(o);
}

long box_get(long x){
  Object* o = untag(x);
  return o->slots[0];
}

long box_set(long x, long v){
  Object* o = untag(x);
  o->slots[0] = v;
  return FALSE_TAG;
}

//=================== CLOSURES ===============================
int num_free(Closure* c){
  long* p = (long*)c->code;
  return (int)p[-1];
}

//=================== STRINGS ================================
int num_words(String* s){
  int len = (int)(s->length);
  return (len + 8)/8;
}

String* allocate_string(int len){
  int sz = sizeof(String) + ((len + 8)&(-8));
  String* str = heap_allocate(sz);
  str->tag = STRING_TAG;
  str->length = len;
  return str;
}

long string_hash(long s){
  String* str = untag(s);
  long h = 0;
  for(int i=0; i<str->length; i++)
    h = 31*h + (int)(str->chars[i]);
  return to_stz_int(h);
}

long literal_string(long x){
  char* s = stanza_string_table[to_int(x)];
  String* str = allocate_string(strlen(s));
  strcpy(str->chars, s);
  return to_ptr(str);
}

long new_string(long x, long c){
  int len = to_int(x);
  String* str = allocate_string(len);
  char ch = to_char(c);
  for(int i=0; i<len; i++)
    str->chars[i] = ch;
  str->chars[len] = 0;
  return to_ptr(str);
}

long string_equal(long s1, long s2){
  String* x = untag(s1);
  String* y = untag(s2);
  return to_stz_bool(strcmp(x->chars, y->chars) == 0);
}

long string_less(long s1, long s2){
  String* x = untag(s1);
  String* y = untag(s2);
  return to_stz_bool(strcmp(x->chars, y->chars) < 0);
}

long string_less_eq(long s1, long s2){
  String* x = untag(s1);
  String* y = untag(s2);
  return to_stz_bool(strcmp(x->chars, y->chars) <= 0);
}

long string_greater(long s1, long s2){
  String* x = untag(s1);
  String* y = untag(s2);
  return to_stz_bool(strcmp(x->chars, y->chars) > 0);
}

long string_greater_eq(long s1, long s2){
  String* x = untag(s1);
  String* y = untag(s2);
  return to_stz_bool(strcmp(x->chars, y->chars) >= 0);
}

char CHAR_BUFFER[32];
long int_to_string(long i){
  int len = sprintf(CHAR_BUFFER, "%ld", to_int(i));
  String* str = allocate_string(len);
  strcpy(str->chars, CHAR_BUFFER);
  return to_ptr(str);
}

long string_to_int(long s){
  String* str = untag(s);
  long i;
  int n = sscanf(str->chars, "%ld", &i);
  if(n == 1)
    return to_stz_int(i);
  else
    return FALSE_TAG;
}

//================= FILES ====================================
long file_exists(long filename){
  String* file = untag(filename);
  FILE* fptr = fopen(file->chars, "r");
  if(!fptr)
    return to_stz_bool(0);
  else{
    fclose(fptr);
    return to_stz_bool(1);
  }
}

long read_file(long filename){
  String* file = untag(filename);
  FILE* fptr = fopen(file->chars, "r");
  if(!fptr){
    printf("File %s not found.\n", file->chars);
    exit(-1);
  }

  //Compute file length
  fseek(fptr,0,SEEK_END);
  int len = ftell(fptr);
  rewind(fptr);

  //Allocate string
  String* ret = allocate_string(len);

  //Read file
  if(fread(ret->chars, 1, len, fptr) != len){
    printf("Error reading from file %s.\n", file->chars);
    exit(-1);
  }
    
  ret->chars[len] = 0;
  fclose(fptr);

  //Return string
  return to_ptr(ret);
}

long write_file(long filename, long string){
  String* file = untag(filename);
  String* str = untag(string);
  FILE* fptr = fopen(file->chars, "w");
  if(!fptr){
    printf("Could not create output file %s.\n", file->chars);
    exit(-1);
  }

  //Write file and close
  fprintf(fptr, "%s", str->chars);
  fclose(fptr);

  //Return false
  return FALSE_TAG;
}

//=============== OUTPUT FILE ================================
long make_outfile(long filename){
  String* file = untag(filename);
  FILE* fptr = fopen(file->chars, "w");
  if(!fptr){
    printf("Could not create output file %s.\n", file->chars);
    exit(-1);
  }
  return (long)fptr;
}

long close_outfile(long fptr){
  fclose((FILE*)fptr);
  return FALSE_TAG;
}

long print_file_int(long fptr, long x){
  fprintf((FILE*)fptr, "%ld", to_int(x));
  return FALSE_TAG;
}

long print_file_float(long fptr, long f){
  Float* x = untag(f);
  fprintf((FILE*)fptr, "%f", x->value);
  return FALSE_TAG;
}

long print_file_char(long fptr, long c){
  fprintf((FILE*)fptr, "%c", to_char(c));
  return FALSE_TAG;
}

long print_file_string(long fptr, long s){
  String* str = untag(s);
  fprintf((FILE*)fptr, "%s", str->chars);
  return FALSE_TAG;
}

long get_stderr(void){
  return (long)stderr;
}

long get_stdout(void){
  return (long)stdout;
}

//================ ARRAYS ====================================
long array_make(long n, long x){
  int len = (int)to_int(n);
  int sz = sizeof(Array) + 8*len;
  int gc_x = make_gcroot(x);
  Array* ar = heap_allocate(sz);
  ar->tag = RAWARRAY_TAG;
  ar->length = len;
  x = delete_gcroot(gc_x);
  for(int i=0; i<len; i++)
    ar->slots[i] = x;
  return to_ptr(ar);
}

long array_get(long xs, long n){
  Array* ar = untag(xs);
  return ar->slots[to_int(n)];
}

long array_set(long xs, long n, long v){
  Array* ar = untag(xs);
  ar->slots[to_int(n)] = v;
  return FALSE_TAG;
}

long array_length(long xs){
  Array* ar = untag(xs);
  return to_stz_int(ar->length);
}

//================== TUPLES ==================================
long tuple_get(long xs, long n){
  Tuple* tup = untag(xs);
  return tup->slots[to_int(n)];
}

long tuple_length(long xs){
  Tuple* tup = untag(xs);
  return tup->length;
}

//================== MEMBLOCK ================================
MemBlock* make_memblock(int bytes){
  int sz = ((bytes + 7)&(-8)) + sizeof(MemBlock);
  MemBlock* b = heap_allocate(sz);
  b->tag = MEMBLOCK_TAG;
  b->bytes = bytes;  
  return b;
}

int block_size(MemBlock* b){
  return ((b->bytes + 7)&(-8)) + sizeof(MemBlock);
}

void* block_ptr(MemBlock* b){
  return b->slots;
}

//================== FLOATS ==================================
Float* make_float(double value){
  Float* f = heap_allocate(sizeof(Float));
  f->tag = FLOAT_TAG;
  f->value = value;
  return f;
}

long literal_float(long i){  
  return to_ptr(make_float(stanza_float_table[to_int(i)]));
}

long float_hi(long a){
  Float* f = untag(a);
  long* l = (long*)(&f->value);
  return to_stz_int(*l >> 32);
}

long float_lo(long a){
  Float* f = untag(a);
  long* l = (long*)(&f->value);
  return to_stz_int((int)*l);
}

long float_neg(long a){
  Float* f = untag(a);
  return to_ptr(make_float(-f->value));
}

long float_plus(long a, long b){
  Float* fa = untag(a);
  Float* fb = untag(b);
  return to_ptr(make_float(fa->value + fb->value));
}

long float_minus(long a, long b){
  Float* fa = untag(a);
  Float* fb = untag(b);
  return to_ptr(make_float(fa->value - fb->value));
}

long float_times(long a, long b){
  Float* fa = untag(a);
  Float* fb = untag(b);
  return to_ptr(make_float(fa->value * fb->value));
}

long float_divide(long a, long b){
  Float* fa = untag(a);
  Float* fb = untag(b);
  return to_ptr(make_float(fa->value / fb->value));
}

long float_modulo(long a, long b){
  Float* fa = untag(a);
  Float* fb = untag(b);
  return to_ptr(make_float(fmod(fa->value, fb->value)));
}

long float_sin(long a){
  Float* f = untag(a);
  return to_ptr(make_float(sin(f->value)));
}

long float_cos(long a){
  Float* f = untag(a);
  return to_ptr(make_float(cos(f->value)));
}

long float_tan(long a){
  Float* f = untag(a);
  return to_ptr(make_float(tan(f->value)));
}

long float_asin(long a){
  Float* f = untag(a);
  return to_ptr(make_float(asin(f->value)));
}

long float_acos(long a){
  Float* f = untag(a);
  return to_ptr(make_float(acos(f->value)));
}

long float_atan(long a){
  Float* f = untag(a);
  return to_ptr(make_float(atan(f->value)));
}

long float_atan2(long a, long b){
  Float* fa = untag(a);
  Float* fb = untag(b);
  return to_ptr(make_float(atan2(fa->value, fb->value)));
}

long float_sqrt(long a){
  Float* f = untag(a);
  return to_ptr(make_float(sqrt(f->value)));
}

long float_pow(long a, long b){
  Float* fa = untag(a);
  Float* fb = untag(b);
  return to_ptr(make_float(pow(fa->value, fb->value)));
}

long float_log(long a){
  Float* f = untag(a);
  return to_ptr(make_float(log(f->value)));
}

long float_log10(long a){
  Float* f = untag(a);
  return to_ptr(make_float(log10(f->value)));
}

long float_exp(long a){
  Float* f = untag(a);
  return to_ptr(make_float(exp(f->value)));
}

long float_less(long a, long b){
  Float* fa = untag(a);
  Float* fb = untag(b);
  return to_stz_bool(fa->value < fb->value);  
}

long float_less_eq(long a, long b){
  Float* fa = untag(a);
  Float* fb = untag(b);
  return to_stz_bool(fa->value <= fb->value);  
}

long float_greater(long a, long b){
  Float* fa = untag(a);
  Float* fb = untag(b);
  return to_stz_bool(fa->value > fb->value);  
}

long float_greater_eq(long a, long b){
  Float* fa = untag(a);
  Float* fb = untag(b);
  return to_stz_bool(fa->value >= fb->value);  
}

long float_equal(long a, long b){
  Float* fa = untag(a);
  Float* fb = untag(b);
  return to_stz_bool(fa->value == fb->value);  
}

long float_to_string(long a){
  Float* f = untag(a);
  int len = sprintf(CHAR_BUFFER, "%f", f->value);
  String* str = allocate_string(len);
  strcpy(str->chars, CHAR_BUFFER);
  return to_ptr(str);  
}

long string_to_float(long s){
  String* str = untag(s);
  double d;
  int n = sscanf(str->chars, "%lf", &d);
  if(n == 1){
    return to_ptr(make_float(d));
  }else
    return FALSE_TAG;
}

long int_to_float(long i){
  return to_ptr(make_float(to_int(i)));
}

long float_truncate(long a){
  Float* f = untag(a);
  return to_stz_int((long)trunc(f->value));
}

long float_ceil(long a){
  Float* f = untag(a);
  return to_stz_int((long)ceil(f->value));
}

long float_floor(long a){
  Float* f = untag(a);
  return to_stz_int((long)floor(f->value));
}

long float_round(long a){
  Float* f = untag(a);
  return to_stz_int((long)round(f->value));
}

//============== RANDOM ======================================
long random_int(void){
  return to_stz_int(rand());
}

//============== COROUTINES ==================================
#define STACK_SIZE (512*1024)
StackSpace* stacklist = 0;
StackSpace* make_stackspace(void){
  if(!stacklist){
    StackSpace* space = heap_allocate(STACK_SIZE);
    space->next = stacklist;
    return space;
  }else{
    StackSpace* space = stacklist;
    stacklist = stacklist->next;
    return space;
  }
}
void free_stackspace(StackSpace* space){
  space->next = stacklist;
  stacklist = space;
}

Coroutine* make_coroutine(long parent){
  int gc_parent = make_gcroot(parent);
  Coroutine* c = heap_allocate(sizeof(Coroutine));
  c->space = make_stackspace();
  c->tag = COROUTINE_TAG;
  c->parent = delete_gcroot(gc_parent);
  c->winders = FALSE_TAG;
  c->status = COROUTINE_OPEN;
  c->sp = c->space->stack;
  c->stanza_rbx = FALSE_TAG;
  c->stanza_rbp = FALSE_TAG;
  c->stanza_r12 = FALSE_TAG;
  c->stanza_r13 = FALSE_TAG;
  c->stanza_r14 = FALSE_TAG;
  return c;
}

void set_current_coroutine(Coroutine* c){
  stanza_coroutine = to_ptr(c);
  stanza_stack_top = (long)(c->space) + STACK_SIZE;
}

long call_coroutine(void){
  Coroutine* c = make_coroutine(stanza_coroutine);
  c->sp[0] = (long)stack_finisher;
  set_current_coroutine(c);
  return to_ptr(c);
}

long current_coroutine(void){
  return stanza_coroutine;
}

long coroutine_winders(long co){
  Coroutine* c = untag(co);
  return c->winders;
}

long coroutine_set_winders(long co, long winders){
  Coroutine* c = untag(co);
  c->winders = winders;
  return FALSE_TAG;
}

long coroutine_parent(long co){
  Coroutine* c = untag(co);
  return c->parent;
}

long resume_coroutine(long co, long x){
  Coroutine* called = untag(co);
  if(called->status != COROUTINE_ENTRANCE){
    printf("Attempt to enter non-rentrant coroutine.\n");
    exit(-1);
  }
  
  long np = stanza_coroutine;
  long cp = called->parent;
  while(1){
    called->parent = np;
    called->status = COROUTINE_OPEN;
    if(cp == FALSE_TAG){
      set_current_coroutine(called);
      return x;
    }
    np = to_ptr(called);
    called = untag(cp);
    cp = called->parent;
  }
}

long suspend_coroutine(long co, long x){
  Coroutine* called = untag(co);
  if(called->status != COROUTINE_OPEN){
    printf("Attempt to suspend non-open coroutine.\n");
    exit(-1);
  }

  long np = FALSE_TAG;
  Coroutine* c = untag(stanza_coroutine);
  long cp = c->parent;
  while(1){
    c->parent = np;
    if(c == called){
      c->status = COROUTINE_ENTRANCE;
      set_current_coroutine(untag(cp));
      return x;
    }else{
      c->status = COROUTINE_SUSPENDED;
      np = to_ptr(c);
      c = untag(cp);
      cp = c->parent;
    }
  }
}

long break_coroutine(long co, long x){
  Coroutine* called = untag(co);
  if(called->status != COROUTINE_OPEN){
    printf("Attempt to break non-open coroutine.\n");
    exit(-1);
  }

  Coroutine* c = untag(stanza_coroutine);
  while(1){
    c->status = COROUTINE_CLOSED;
    free_stackspace(c->space);
    if(c == called){
      set_current_coroutine(untag(c->parent));
      return x;
    }
    c = untag(c->parent);
  }
}

long close_coroutine(long co){
  Coroutine* called = untag(co);
  if(called->status == COROUTINE_CLOSED)
    return FALSE_TAG;
  
  if(called->status != COROUTINE_ENTRANCE){
    printf("Attempt to close non-rentrant coroutine.\n");
    exit(-1);
  }

  //Release all stacks
  while(co != FALSE_TAG){
    Coroutine* c = untag(co);
    c->status = COROUTINE_CLOSED;
    free_stackspace(c->space);
    co = c->parent;
  }
  return FALSE_TAG;
}

long isopen_coroutine(long co){
  Coroutine* called = untag(co);
  return to_stz_bool(called->status == COROUTINE_OPEN ||
                     called->status == COROUTINE_ENTRANCE);
}

//================ STACK EXTENSION ===========================
void extend_stack(long size){
  if(size >= STACK_SIZE){
    printf("Stack is too small for requested frame of %ld bytes.\n", size);
    exit(-1);
  }
  Coroutine* c = make_coroutine(stanza_coroutine);

  //Copy over frame to new stack
  c->sp[0] = (long)stack_finisher;
  Coroutine* current = untag(stanza_coroutine);
  int sz = current->sp[1];
  for(int i=1; i<2+sz; i++)
    c->sp[i] = current->sp[i];
  
  //Set as current coroutine
  set_current_coroutine(c);
}

void finish_stack(void){
  Coroutine* current = untag(stanza_coroutine);
  current->status = COROUTINE_CLOSED;
  free_stackspace(current->space);
  set_current_coroutine(untag(current->parent));
}

//=============== STACK TRACE ================================
char* lookup_stack_map(long ret){
  for(int i=0; i<stanza_stack_mapping.num_entries; i++)
    if(stanza_stack_mapping.entries[i].ret == ret)
      return stanza_stack_mapping.entries[i].description;
  return "NoFile";
}

void print_trace(Coroutine* c){
  //Count trace size
  int n = 0;
  long* scan = c->space->stack;
  scan += scan[1] + 2;
  while(scan <= c->sp){
    n += 1;
    scan += scan[1] + 2;
  }

  //Collect trace
  char** trace = malloc(n * sizeof(char*));
  n = 0;
  scan = c->space->stack;
  scan += scan[1] + 2;
  while(scan <= c->sp){
    trace[n] = lookup_stack_map(scan[0]);
    n += 1;
    scan += scan[1] + 2;
  }

  //Print and Free Trace
  for(int i=n-1; i>=0; i--)
    fprintf(stderr, "   at %s\n", trace[i]);
  free(trace);

  //Print parent trace
  if(c->parent != FALSE_TAG)
    print_trace(untag(c->parent));
}

long print_stack_trace(void){
  print_trace(untag(stanza_coroutine));
  return FALSE_TAG;
}

//================== MEMORY ==================================
#define HEAP_SIZE (1024*1024*1024)
long* heap_mem;
long* free_mem;

void set_current_heap(long* heap){
  stanza_heap = (long)heap;
  stanza_heap_top = (long)heap + HEAP_SIZE;
}

void init_memory(void){
  heap_mem = malloc(HEAP_SIZE);
  free_mem = malloc(HEAP_SIZE);
  set_current_heap(heap_mem);
}

void* heap_allocate(int size){
  if(stanza_heap + size >= stanza_heap_top)
    extend_heap(size);
  long* ret = (long*)stanza_heap;
  stanza_heap += size;
  return ret;  
}

//================ GARBAGE COLLECTION ========================
#define BROKEN_HEART_TAG 0xFFFFFFFFFFFFFFFF
typedef struct {
  long tag;
  long forward;
} BrokenHeart;

void extend_heap(long size){
  //Swap heap and free
  long* swap = heap_mem;
  heap_mem = free_mem;
  free_mem = swap;
  set_current_heap(heap_mem);

  //Free stacklist
  stacklist = 0;

  //Copy Globals
  for(int i=0; i<stanza_num_globals; i++)
    stanza_globals[i] = copy_ptr(stanza_globals[i]);
  //Copy GCRoots
  for(int i=0; i<gcroots.cap; i++)
    gcroots.roots[i] = copy_ptr(gcroots.roots[i]);
  //Copy registers
  stanza_rax = copy_ptr(stanza_rax);
  stanza_rcx = copy_ptr(stanza_rcx);
  stanza_rdx = copy_ptr(stanza_rdx);
  stanza_rsi = copy_ptr(stanza_rsi);
  stanza_rdi = copy_ptr(stanza_rdi);
  stanza_r8 = copy_ptr(stanza_r8);
  stanza_r9 = copy_ptr(stanza_r9);
  stanza_r10 = copy_ptr(stanza_r10);
  stanza_r11 = copy_ptr(stanza_r11);
  //Copy roots
  stanza_closure = copy_ptr(stanza_closure);
  set_current_coroutine(untag(copy_ptr(stanza_coroutine)));
  //Link
  link_heap();

  //Calculate New Heap Remaining
  long new_remaining = stanza_heap_top - stanza_heap;
  if(new_remaining < size){
    printf("Out of Memory\n");
    exit(-1);
  }
}

long copy_ptr(long ptr){
  //Immediates
  if(prim_tag(ptr) != OBJECT_TAG)
    return ptr;

  //Broken Hearts
  Object* o = untag(ptr);
  if(o->tag == BROKEN_HEART_TAG)
    return ((BrokenHeart*)o)->forward;

  //Copy
  long copied;
  switch(o->tag){
  case FN_TAG:
    copied = copy_closure((Closure*)o);
    break;
  case STRING_TAG:
    copied = copy_string((String*)o);
    break;
  case RAWARRAY_TAG:
    copied = copy_array((Array*)o);
    break;
  case TUPLE_TAG:
    copied = copy_tuple((Tuple*)o);
    break;
  case COROUTINE_TAG:
    copied = copy_coroutine((Coroutine*)o);
    break;
  case FLOAT_TAG:
    copied = copy_float((Float*)o);
    break;
  case MEMBLOCK_TAG:
    copied = copy_memblock((MemBlock*)o);
    break;
  default:
    copied = copy_object(o);
    break;
  }

  //Leave Broken Heart and Return
  BrokenHeart* heart = (BrokenHeart*)o;
  heart->tag = BROKEN_HEART_TAG;
  heart->forward = copied;
  return copied;
}

void copy_range(long* dest, long* src, int n){
  for(int i=0; i<n; i++)
    dest[i] = src[i];
}

long copy_closure(Closure* c){
  int n = num_free(c);
  long* new_c = heap_allocate(sizeof(Closure) + 8*n);
  copy_range(new_c, (long*)c, n + 2);
  return to_ptr(new_c);
}

long copy_object(Object* o){
  int n = max(1,num_slots(o));
  long* new_o = heap_allocate(sizeof(Object) + 8*n);
  copy_range(new_o, (long*)o, n + 1);
  return to_ptr(new_o);
}

long copy_coroutine(Coroutine* c){
  Coroutine* new_c = heap_allocate(sizeof(Coroutine));
  new_c->tag = COROUTINE_TAG;
  new_c->parent = c->parent;
  new_c->winders = c->winders;
  new_c->status = c->status;
  new_c->stanza_rbx = c->stanza_rbx;
  new_c->stanza_rbp = c->stanza_rbp;
  new_c->stanza_r12 = c->stanza_r12;
  new_c->stanza_r13 = c->stanza_r13;
  new_c->stanza_r14 = c->stanza_r14;
  if(new_c->status != COROUTINE_CLOSED){
    new_c->space = make_stackspace();
    int n = c->sp[1] + (c->sp + 2) - (c->space->stack);
    copy_range(new_c->space->stack, c->space->stack, n);
    new_c->sp = (c->sp - c->space->stack) + new_c->space->stack;
  }
  return to_ptr(new_c);
}

long copy_string(String* s){
  int n = num_words(s);
  long* new_s = heap_allocate(sizeof(String) + 8*n);
  copy_range(new_s, (long*)s, n + 2);
  return to_ptr(new_s);
}

long copy_array(Array* ar){
  long* new_ar = heap_allocate(sizeof(Array) + 8*ar->length);
  copy_range(new_ar, (long*)ar, ar->length + 2);
  return to_ptr(new_ar);
}

long copy_tuple(Tuple* tup){
  int len = to_int(tup->length);
  long* new_tup = heap_allocate(sizeof(Tuple) + 8*len);
  copy_range(new_tup, (long*)tup, len + 2);
  return to_ptr(new_tup);
}

long copy_memblock(MemBlock* b){
  int sz = block_size(b);
  void* blk = heap_allocate(sz);
  memcpy(blk, b, sz);
  return to_ptr(blk);
}

long copy_float(Float* f){
  return to_ptr(make_float(f->value));
}

void link_heap(void){
  long* scan = (long*)heap_mem;
  while(scan < (long*)stanza_heap){
    switch(scan[0]){
    case FN_TAG:
      scan = link_closure((Closure*)scan);
      break;
    case STRING_TAG:
      scan = link_string((String*)scan);
      break;
    case RAWARRAY_TAG:
      scan = link_array((Array*)scan);
      break;
    case TUPLE_TAG:
      scan = link_tuple((Tuple*)scan);
      break;
    case COROUTINE_TAG:
      scan = link_coroutine((Coroutine*)scan);
      break;
    case FLOAT_TAG:
      scan = link_float((Float*)scan);
      break;
    case MEMBLOCK_TAG:
      scan = link_memblock((MemBlock*)scan);
      break;
    default:
      scan = link_object((Object*)scan);
      break;
    }
  }
}

long* link_range(long* p, int n){
  for(int i=0; i<n; i++)
    p[i] = copy_ptr(p[i]);
  return p + n;
}

long* link_closure(Closure* c){
  return link_range(c->free, num_free(c));
}

long* link_object(Object* o){
  int n = num_slots(o);
  if(n>0)
    return link_range(o->slots, n);
  return o->slots + 1;
}

long* link_coroutine(Coroutine* c){
  c->parent = copy_ptr(c->parent);
  c->winders = copy_ptr(c->winders);
  c->stanza_rbx = copy_ptr(c->stanza_rbx);
  c->stanza_rbp = copy_ptr(c->stanza_rbp);
  c->stanza_r12 = copy_ptr(c->stanza_r12);
  c->stanza_r13 = copy_ptr(c->stanza_r13);
  c->stanza_r14 = copy_ptr(c->stanza_r14);
  if(c->status != COROUTINE_CLOSED){
    long* scan = c->space->stack;
    while(scan <= c->sp){
      long n = scan[1];
      scan = link_range(scan+2, n);
    }
    return (long*)((long)c->space + STACK_SIZE);
  }
  return (long*)(c + 1);
}

long* link_string(String* s){
  int n = num_words(s);
  return (long*)s + n + 2;
}

long* link_memblock(MemBlock* b){
  return (void*)b + block_size(b);
}

long* link_array(Array* ar){
  return link_range(ar->slots, ar->length);
}

long* link_tuple(Tuple* tup){
  int len = to_int(tup->length);
  return link_range(tup->slots, len);
}

long* link_float(Float* f){
  return (long*)(f + 1);
}

//============== CONSISTENCY CHECK ===========================
long phase_counter = FALSE_TAG;
void check_consistency(void){
  phase_counter += 8;
  for(int i=0; i<stanza_num_globals; i++)
    check_ptr(stanza_globals[i]);
  for(int i=0; i<gcroots.cap; i++)
    check_ptr(gcroots.roots[i]);
  check_ptr(stanza_closure);
  check_ptr(stanza_coroutine);
  check_ptr(stanza_rax);
  check_ptr(stanza_rcx);
  check_ptr(stanza_rdx);
  check_ptr(stanza_rsi);
  check_ptr(stanza_rdi);
  check_ptr(stanza_r8);
  check_ptr(stanza_r9);
  check_ptr(stanza_r10);
  check_ptr(stanza_r11);
}

void in_heap(void* p){
  long* lp = (long*)p;
  if(lp < heap_mem || lp >= heap_mem + HEAP_SIZE){
    printf("0x%lx not in heap [%lx to %lx]!\n", (long)lp,
           (long)heap_mem, (long)heap_mem + HEAP_SIZE);
    exit(-1);
  }
}

void in_free(void* p){
  long* lp = (long*)p;
  if(lp < free_mem || lp >= free_mem + HEAP_SIZE){
    printf("0x%lx not in heap!\n", (long)lp);
    exit(-1);
  }
}

void check_ptr(long ptr){
  //Check valid ptr
  if(prim_tag(ptr) != OBJECT_TAG){
    check_immediate(ptr);
    return;
  }

  //Check pointer is in heap
  in_heap(untag(ptr));

  //Ensure we haven't already checked!
  long* phase_ptr = untag(ptr + (long)free_mem - (long)heap_mem);
  if(*phase_ptr == phase_counter)
    return;
  *phase_ptr = phase_counter;

  //Recurse
  Object* o = untag(ptr);
  switch(o->tag){
  case FN_TAG:
    check_closure((Closure*)o);
    break;
  case STRING_TAG:
    break;
  case RAWARRAY_TAG:
    check_array((Array*)o);
    break;
  case TUPLE_TAG:
    check_tuple((Tuple*)o);
    break;
  case COROUTINE_TAG:
    check_coroutine((Coroutine*)o);
    break;
  case FLOAT_TAG:
    break;
  default:
    check_object((Object*)o);
    break;
  }
}

void check_immediate(long x){
  int known = 1;
  switch(prim_tag(x)){
  case INT_TAG: break;
  case INT_TAG2: break;
  case CHAR_TAG: break;
  case TRUE_TAG:
    known = (x == TRUE_TAG);
    break;
  case FALSE_TAG:
    known = (x == FALSE_TAG);
    break;
  default:
    known = 0;
    break;
  }
  if(!known){
    fprintf(stderr, "Unknown Immediate: %lx\n", x);
    exit(-1);
  }
}

void check_range(long* p, int n){
  for(int i=0; i<n; i++)
    check_ptr(p[i]);
}

void check_array(Array* a){
  check_range(a->slots, a->length);
}

void check_tuple(Tuple* tup){
  int len = to_int(tup->length);
  check_range(tup->slots, len);
}

void check_closure(Closure* c){
  check_range(c->free, num_free(c));
}

void check_object(Object* o){
  int n = num_slots(o);
  if(n>0)
    check_range(o->slots, n);
}

void check_coroutine(Coroutine* c){
  check_ptr(c->parent);
  long* scan = c->space->stack;
  while(scan <= c->sp){
    int n = scan[1];
    check_range(scan+2, n);
    scan += n+2;
  }
}

//================= INPUT ARGUMENTS ==========================
char* input_args;
void save_input_args(int argc, char** argv){
  //Count characters
  int nc = 0;
  for(int i=0; i<argc; i++)
    nc += strlen(argv[i]) + 1;
  //Copy
  input_args = malloc(nc + 1);
  char* dst = input_args;
  for(int i=0; i<argc; i++)
    dst += sprintf(dst, "%s ", argv[i]);
}

long commandline_arguments(void){
  String* str = allocate_string(strlen(input_args));
  strcpy(str->chars, input_args);
  return to_ptr(str);
}

char* proc_path;
void save_proc_path(char** argv){
  proc_path = realpath(argv[0], NULL);
  if(!proc_path){
    fprintf(stderr, "Failed to get procedure path: %s\n", strerror(errno));
    exit(-1);
  }
}

long procedure_path(void){
  String* str = allocate_string(strlen(proc_path));
  strcpy(str->chars, proc_path);
  return to_ptr(str);
}

//============== SYSTEM CALLS ================================
long call_system(long string){
  String* str = untag(string);
  int result = system(str->chars);
  if(result == -1){
    perror("System call failed: ");
    exit(-1);
  }
  return to_stz_int(result);
}

//=============== MACHINE ====================================
long run_stanza(int argc, char** argv){
  //Save off input arguments
  save_input_args(argc, argv);
  save_proc_path(argv);
  //Set heap
  init_gcroots();
  init_memory();
  //Set coroutine
  set_current_coroutine(make_coroutine(FALSE_TAG));
  //Run!
  return stanza_entry();  
}

#define MAX_NARGS 64
int argbuffer[MAX_NARGS];
long call_stanza(long f, int nargs, long* args){
  //Create new coroutine
  int gc_f = make_gcroot(f);
  for(int i=0; i<nargs; i++)
    argbuffer[i] = make_gcroot(args[i]);
  Coroutine* c = make_coroutine(stanza_coroutine);
  set_current_coroutine(c);

  //Set Arguments
  stanza_arity = nargs;
  stanza_closure = delete_gcroot(gc_f);
  for(int i=6; i<nargs; i++)
    c->space->stack[2+i-6] = delete_gcroot(argbuffer[i]);

  //Call into Stanza
  long saved_c_rbx = c_rbx;
  long saved_c_rsp = c_rsp;
  long saved_c_rbp = c_rbp;
  long saved_c_r12 = c_r12;
  long saved_c_r13 = c_r13;
  long saved_c_r14 = c_r14;
  long saved_c_r15 = c_r15;  
  long ret = stanza_start(
               nargs>0? delete_gcroot(argbuffer[0]) : 0,
               nargs>1? delete_gcroot(argbuffer[1]) : 0,
               nargs>2? delete_gcroot(argbuffer[2]) : 0,
               nargs>3? delete_gcroot(argbuffer[3]) : 0,
               nargs>4? delete_gcroot(argbuffer[4]) : 0,
               nargs>5? delete_gcroot(argbuffer[5]) : 0);
  c_rbx = saved_c_rbx;
  c_rsp = saved_c_rsp;
  c_rbp = saved_c_rbp;
  c_r12 = saved_c_r12;
  c_r13 = saved_c_r13;
  c_r14 = saved_c_r14;
  c_r15 = saved_c_r15;
  
  //Restore previous coroutine
  c = untag(stanza_coroutine);
  set_current_coroutine(untag(c->parent));
  
  //Return result
  return ret;
}
