#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>

int input_argc;
char** input_argv;

long stanza_entry(void* stack, void* heap, void* free) __asm__("stanza_entry");
void run_stanza(int argc, char** argv){
  input_argc = argc;
  input_argv = argv;
  void* heap_mem = malloc(1024*1024*1024);
  void* stack_mem = malloc(1024*1024*1024);
  void* free_mem = malloc(1024*1024*1024);
  stanza_entry(stack_mem, heap_mem, free_mem);
}

//================ Current Time ===============================
long current_time_us (void) {
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec*1000*1000 + tv.tv_usec;
}

//================= File Streams ==============================
int FILE_SEEK_END = SEEK_END;
FILE* get_stderr (){return stderr;}
FILE* get_stdout (){return stdout;}
FILE* get_stdin (){return stdin;}

void fprintfloat(FILE* file, int x){
  float f = *(float*)&x;
  fprintf(file, "%f", f);
}

int sprintfloat (char* chars, int x){
  float f = *(float*)&x;
  return sprintf(chars, "%f", f);
}

int float_plus (int x, int y){
  float fx = *(float*)&x;
  float fy = *(float*)&y;
  float r = fx + fy;
  return *(int*)&r;
}

int float_minus (int x, int y){
  float fx = *(float*)&x;
  float fy = *(float*)&y;
  float r = fx - fy;
  return *(int*)&r;
}

int float_times (int x, int y){
  float fx = *(float*)&x;
  float fy = *(float*)&y;
  float r = fx * fy;
  return *(int*)&r;
}

int float_divide (int x, int y){
  float fx = *(float*)&x;
  float fy = *(float*)&y;
  float r = fx / fy;
  return *(int*)&r;
}

int float_sin (int x){
  float fx = *(float*)&x;
  float r = sin(fx);
  return *(int*)&r;
}

int float_cos (int x){
  float fx = *(float*)&x;
  float r = cos(fx);
  return *(int*)&r;
}

int float_tan (int x){
  float fx = *(float*)&x;
  float r = tan(fx);
  return *(int*)&r;
}

int float_asin (int x){
  float fx = *(float*)&x;
  float r = asin(fx);
  return *(int*)&r;
}

int float_acos (int x){
  float fx = *(float*)&x;
  float r = acos(fx);
  return *(int*)&r;
}

int float_atan (int x){
  float fx = *(float*)&x;
  float r = atan(fx);
  return *(int*)&r;
}

int float_atan2 (int x, int y){
  float fx = *(float*)&x;
  float fy = *(float*)&y;
  float r = atan2(fx, fy);
  return *(int*)&r;
}

int float_sqrt (int x){
  float fx = *(float*)&x;
  float r = sqrt(fx);
  return *(int*)&r;
}

int float_pow (int x, int y){
  float fx = *(float*)&x;
  float fy = *(float*)&y;
  float r = pow(fx, fy);
  return *(int*)&r;
}

int float_log (int x){
  float fx = *(float*)&x;
  float r = log(fx);
  return *(int*)&r;
}

int float_log10 (int x){
  float fx = *(float*)&x;
  float r = log10(fx);
  return *(int*)&r;
}

int float_exp (int x){
  float fx = *(float*)&x;
  float r = exp(fx);
  return *(int*)&r;
}

int float_less (int x, int y){
  float fx = *(float*)&x;
  float fy = *(float*)&y;
  return fx < fy;
}

int float_less_eq (int x, int y){
  float fx = *(float*)&x;
  float fy = *(float*)&y;
  return fx <= fy;
}

int float_greater (int x, int y){
  float fx = *(float*)&x;
  float fy = *(float*)&y;
  return fx > fy;
}

int float_greater_eq (int x, int y){
  float fx = *(float*)&x;
  float fy = *(float*)&y;
  return fx >= fy;
}

int float_ceil (int x){
  float fx = *(float*)&x;
  float r = ceil(fx);
  return *(int*)&r;
}

int float_floor (int x){
  float fx = *(float*)&x;
  float r = floor(fx);
  return *(int*)&r;
}

int float_round (int x){
  float fx = *(float*)&x;
  float r = round(fx);
  return *(int*)&r;
}
